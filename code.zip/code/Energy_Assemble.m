function [SignalvsEnergy_assemble1,SignalvsEnergy_assemble2 ] = Energy_Assemble(spikes1,spikes2,connection2to1,connection1to2,weight2to1,weight1to2,assemble1,assemble2)
N_situation = size(spikes1,4);
N_assemble = size(assemble1,1);
SignalvsEnergy_assemble1 = zeros(N_assemble,N_assemble,N_situation,2);
SignalvsEnergy_assemble2 = zeros(N_assemble,N_assemble,N_situation,2);
for n = 1:N_situation
    clear Energy1;clear Energy2;
    % energy of neural assemble over simulations are calcualted with spikes
    Energy1 = mean(mean(spikes1(:,:,:,n),3),2);
    Energy2 = mean(mean(spikes2(:,:,:,n),3),2);

    for nn1 = 1:N_assemble
        for nn2 = 1:N_assemble
            % find neurons in each assemble
            neuron1 = assemble1{nn1,1};
            neuron2 = assemble2{nn2,1};
            
            if (~isempty(neuron1))&&(~isempty(neuron2))
                

            % energy from nn2 th assemble in no.2 group to nn1 th assemble in no.1 group
            clear Signal_0;clear Signal_1;
            for mm1 = 1:length(neuron1)
                Signal_0(mm1,:) = connection2to1(neuron1(mm1,1),:)*weight2to1*Energy2;
            end
            SignalvsEnergy_assemble1(nn1,nn2,n,1) = mean(Signal_0,1)/mean(Energy2(neuron2),1);% signal transformed by each unit of energy
            SignalvsEnergy_assemble2(nn1,nn2,n,1) = sum(Signal_0,1)/sum(Energy2(neuron2),1);
            % energy from nn1 th assemble in no.1 group to nn2 th assemble in no.2 group
            clear Signal_0;clear Signal_1;
            for mm2 = 1:length(neuron2)
                Signal_0(mm2,:) = connection1to2(neuron2(mm2,1),:)*weight1to2*Energy1;
            end
            SignalvsEnergy_assemble1(nn2,nn1,n,2) = mean(Signal_0,1)/mean(Energy1(neuron1),1);
            SignalvsEnergy_assemble2(nn2,nn1,n,2) = sum(Signal_0,1)/sum(Energy1(neuron1),1);
        
            end
        end
    end
end

top1 = max(SignalvsEnergy_assemble2(:));bottom1 = min(SignalvsEnergy_assemble2(:));
figure;
for n = 1:N_situation
  subplot(2,2,(n-1)*N_situation + 1);imshow((SignalvsEnergy_assemble1(:,:,n,1)-bottom1)/(top1 - bottom1));
  subplot(2,2,(n-1)*N_situation + 2);imshow((SignalvsEnergy_assemble1(:,:,n,2)-bottom1)/(top1 - bottom1));
end
figure;
top1 = max(SignalvsEnergy_assemble2(:));bottom1 = min(SignalvsEnergy_assemble2(:));
figure;
for n = 1:N_situation
  subplot(2,2,(n-1)*N_situation + 1);imshow((SignalvsEnergy_assemble2(:,:,n,1)-bottom1)/(top1 - bottom1));
  subplot(2,2,(n-1)*N_situation + 2);imshow((SignalvsEnergy_assemble2(:,:,n,2)-bottom1)/(top1 - bottom1));
end


end