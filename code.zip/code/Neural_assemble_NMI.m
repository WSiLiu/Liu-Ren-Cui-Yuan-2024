function NMI_assemble = Neural_assemble_NMI(rate1,rate2,connection1,connection2,Assembles1,Assembles2)
Res = [];Res1 = [];
for mm = 1:size(rate1,4)
    % for each situaion,spiking counts of each neuron is measured over situations
    for nn = 1:size(rate1,1)
        Res = rate1(nn,1,:,mm);
%         if sum(Res(:))~=0
         Res1(nn,:,mm) = Res(:)';
%         end
    end 
end
Res = [];Res2 = [];
for mm = 1:size(rate2,4)
    % for each situaion,spiking counts of each neuron is measured over situations
    for nn = 1:size(rate2,1)
        Res = rate2(nn,1,:,mm);
%         if sum(Res(:))~=0
         Res2(nn,:,mm) = Res(:)';
%         end
    end 
end

bottom1 = min(Res2(:));top1 = max(Res2(:));
edge = (bottom1-0.5):1:(top1+0.5);% range of neural spiking counts


MI = zeros(1,1);NMI = zeros(1,1);
for mm = 1:size(rate2,4)
    % for each situaion,spiking counts of each neuron is measured over situations
    for nn = 1:size(Res1,1)
        for nn1 = 1:size(Res2,1)
            x = Res1(nn,:,mm);
            x = x(:);
            y = Res2(nn1,:,mm);
            y = y(:);
            if (sum(x(:))~=0)&&(sum(y(:))~=0)
            [mi, nmi] = mutual_info(x, y, edge);
            MI(nn,nn1,mm) = mi*double(connection1(nn,nn1)||connection2(nn1,nn));
            NMI(nn,nn1,mm) = nmi*double(connection1(nn,nn1)||connection2(nn1,nn));% NMIs are calculated with connections considered
            else
                NMI(nn,nn1,mm) = -1;
            end
        end
    end
end
NMI_assemble = cell(size(Assembles1,1),size(Assembles1,1),2);
for nn1 = 1:size(Assembles1,1)
    for nn2 = 1:size(Assembles2,1)
        clear neuron1;clear neuron2;
        neuron1 = Assembles1{nn1,1};
        neuron2 = Assembles2{nn1,1};
        if (~isempty(neuron1))&&(~isempty(neuron2))
        NMI0 = NMI(neuron1,:,:);
        NMI1 = NMI0(:,neuron2,:);
        NMI_assemble{nn1,nn2,1} = NMI1(:,:,1);
        NMI_assemble{nn1,nn2,2} = NMI1(:,:,2);
        end
    end
end
figure;
for nn3 = 1:2
    for nn1 = 1:size(Assembles1,1)
        for nn2 = 1:size(Assembles1,1)
            clear NMI0;
            NMI0 = NMI_assemble{nn1,nn2,nn3};
            NMI0 = NMI0(NMI0>=0);
            if sum(NMI0(:))>0
            mu(nn1,nn2,nn3) = mean(NMI0(:));
            x = nn1;y = nn2;z1 = mu(nn1,nn2,nn3);
            if nn3 == 1
               type0 = 'o';
            else
               type0 = '*';
            end
            plot3(x,y,z1,type0,'Color',[0.5 0.5 0.5],'MarkerSize',15);hold on;
            end
        end
    end
end
grid on;
xlim([0.5 3.5]);ylim([0.5 3.5]);
% xticks([1 2 3]);yticks([1 2 3]);
end