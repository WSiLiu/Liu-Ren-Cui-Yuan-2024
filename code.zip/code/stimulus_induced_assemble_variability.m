function stimulus_induced_assemble_variability(N_assemble,Z_rate,assembles)
N_neuron = size(Z_rate);
clear alpha;% neural responses are compared over different situations.
for nn = 1:N_neuron
    clear Zleft_responses0;
    Zleft_responses0 = [Z_rate(nn,:,:,1);Z_rate(nn,:,:,2)];% neural firing rates in each situation and each time step
    clear Zleft_responses_ave_oversimulation;
    Zleft_responses00 = mean(Zleft_responses0,1);
    for t = 1:size(Zleft_responses00,2)
        Zleft_responses01 = Zleft_responses00(1,t,:);
        Zleft_responses_ave_oversimulation(t,1) = var(Zleft_responses01(:));% var. over simulation
    end
    % Zleft_responses_ave_oversimulation = var(mean(Zleft_responses0,1),3);
    var1 = mean(Zleft_responses_ave_oversimulation);% ave. over time
    Zleft_responses_situationtime = Zleft_responses0(:); 
    var2 = var(Zleft_responses_situationtime);% var. over both simulation and time
    if var2 == 0
        alpha(nn,1) = 1;
    else
        alpha(nn,1) = 1 - var1/var2;
    end
end
Assemble_alpha = cell(N_assemble,1);
N = 0;clear a1;clear b1;
 for n1 = 1:N_assemble
    clear neurons;
    neurons = assembles{n1,1};
    if ~isempty(neurons)
    N = N + 1;
    Assemble_alpha{n1,1} = alpha(neurons,:);
    [a0,b0] = hist(Assemble_alpha{n1,1}(:));
    a1(:,n1) = a0./sum(a0);
    b1(:,n1) = b0;
    end
%     subplot(1,3,n1);bar(b0,a1,'Facecolor',[0.5,0.5,0.5]);ylim([0,1.1*max(a1(:))]);hold on;
 end
 
 figure;
for n1 = 1:size(a1,2)
    a0 = a1(:,n1);b0 = b1(:,n1);
    subplot(1,N,n1);bar(b0,a0,'Facecolor',[0.5,0.5,0.5]);ylim([0,1.1*max(a1(:))]);hold on;
end
end
