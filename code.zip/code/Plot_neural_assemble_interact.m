function Plot_neural_assemble_interact(top0,bottom0,Assembles1,Assembles2,p_Assemble,N_situation)
p_Assemble0 = [];j = 0;
for n1 = 1:size(Assembles1,1)
    if ~isempty(Assembles1{n1,1})
        j = j + 1;
        p_Assemble0(:,j,:) = p_Assemble(:,n1,:);
    end
end
p_Assemble1 = [];j = 0;
for n1 = 1:size(Assembles2,1)
    if ~isempty(Assembles2{n1,1})
        j = j + 1;
        p_Assemble1(j,:,:) = p_Assemble0(n1,:,:);
    end
end


figure;
for nn = 1:N_situation
    subplot(1,N_situation,nn)
    imshow(p_Assemble1(:,:,nn));hold on
    caxis([bottom0, top0]); % range in imshow()
    colorbar;
end
end