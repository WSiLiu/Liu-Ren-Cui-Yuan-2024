function version = snn_version
% snn_version: retruns the toolbox version string
%
% version = snn_version
%
% David Kappel 17.11.2010
%

    version = '1.7';
end
