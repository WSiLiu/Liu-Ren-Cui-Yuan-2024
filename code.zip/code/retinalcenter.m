function center = retinalcenter(n,n1,n2,I0,d)

    x0 = floor(n/length(n2))+1*(rem(n,length(n2))~=0);
    x = n1(1,floor(x0));
    y = n2(1,floor(n-length(n2)*(x0-1)));
%     dx = 0.5*d-unifrnd(0,1)*d; dy = 0.5*d+(-1)^(unifrnd(0,1)>0.5)*sqrt(d^2-(dx)^2);
%     x = x + dx;y = y + dy;
%     x1 = x+2-d/2*unifrnd(0,1,1,1);
%     y1 = y+2-d/2*unifrnd(0,1,1,1);
    x = floor(max(1,min(x,size(I0,2))));y = floor(max(1,min(y,size(I0,1))));
    %x = x - size(I0,2)/2;y = y - size(I0,1)/2;
%     x1 = floor(max(1,min(x1,size(I,2)))-size(I,2)/2);y1 = floor(max(1,min(y1,size(I,1)))-size(I,1)/2);
    center = [x,y,x,y];
 end