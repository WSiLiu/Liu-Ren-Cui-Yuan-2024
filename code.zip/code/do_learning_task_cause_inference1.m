function [save_path,patterns] = do_learning_task_cause_inference1( exp_path, pat_sequences, varargin )
% DO_LEARNING_TASK runs an experiment that uses the HMM SEM network
% 
% function save_path = do_learning_task( exp_path, pat_sequences, ... )
%
% Train patterns into a HMM SEM network. Returns path that contains the
% training results.
%
% 02.11.2011
% David Kappel
%

%% init

    [ num_bio_neurons, ...
      num_inputs, ...
      pattern_length, ...
      length_std, ...
      noise_length, ...
      input_rate, ...
      output_rate, ...
      num_train_sets, ...
      targets_per_pattern, ...
      num_patterns, ...
      num_samples, ...
      num_runs, ...
      num_train_samples, ...
      free_run_time, ...
      free_run_seqs, ...
      free_run_pat_lenghts, ...
      seq_probs, ...
      seq_ids, ...
      rec_delay, ...
      eta, ...
      save_interval, ...
      free_run_noise, ...
      iw_track_speed, ...
      w_rf, ...
      use_iw, ...
      reset_psps, ...
      use_variance_tracking, ...
      self_inhibition, ...
      tau_x_r, ...
      tau_z_r, ...
      tau_x_f, ...
      tau_z_f, ...
      tau_rf, ...
      train_method, ...
      sample_method, ...
      show_fig, ...
      pat_labels, ...
      pat_alpha, ...
      pat_beta, ...
      num_epochs, ...
      train_set_generator, ...
      performance_method, ...
      pattern_type, ...
      patterns, ...
      pretrain_ff_weights, ...
      field_collectors, ...
      net_V, ...
      input_process, ...
      regen_patterns, ...
      regen_seqs, ...
      groups, ...
      base_path, ...      
      changelog_flag, ...
      state, ...
      T, ...
      stimulus, ...
      N_cue, ...
      cue, ...
      varargin ] = snn_process_options( varargin, ...
                                        'num_bio_neurons', [], ...
                                        'num_inputs', [], ...
                                        'pattern_length', [], ...
                                        'length_std', 0.000, ...
                                        'noise_length', 0, ...
                                        'input_rate', 100, ...
                                        'output_rate', 200, ...
                                        'num_train_sets', 1000, ...
                                        'targets_per_pattern', 10, ...
                                        'num_patterns', [], ...
                                        'num_samples', 10, ...
                                        'num_runs', 1, ...
                                        'num_train_samples', 3, ...
                                        'free_run_time', [], ...
                                        'free_run_seqs', [], ...
                                        'free_run_pat_lenghts', [], ...
                                        'seq_probs', [], ...
                                        'seq_ids', [], ...
                                        'rec_delay', 0.000, ...
                                        'eta', [], ...
                                        'save_interval', [], ...
                                        'free_run_noise', 0.00, ...
                                        'iw_track_speed', 0.001, ...
                                        'w_rf', 0, ...
                                        'use_iw', false, ...
                                        'reset_psps', false, ...
                                        'use_variance_tracking', false, ...
                                        'self_inhibition', 0, ...
                                        'tau_x_r', 0.002, ...
                                        'tau_z_r', 0.002, ...
                                        'tau_x_f', 0.02, ...
                                        'tau_z_f', 0.02, ...
                                        'tau_rf', 0.005, ...
                                        'train_method', 'rs', ...
                                        'sample_method', 'ctrfstere', ...
                                        'show_fig', false, ...
                                        'pat_labels', [], ...
                                        'pat_alpha', 0.2, ...
                                        'pat_beta', 0.8, ...
                                        'num_epochs', 1, ...
                                        'train_set_generator', [], ...                                        
                                        'performance_method', 'ct', ...
                                        'pattern_type', 'beta', ...
                                        'patterns', [], ...
                                        'pretrain_ff_weights', false, ...
                                        'collect', '[At,R]', ...
                                        'net_V', [], ...
                                        'input_process', 'poisson', ...
                                        'regen_patterns', false, ...
                                        'regen_seqs', false, ...
                                        'groups', [], ...
                                        'base_path', '', ...
                                        'changelog_flag', [], ...
                                        'state',[], ...
                                        'T', [], ...
                                        'stimulus', [], ...
                                        'N_cue', [], ...
                                        'cue', []);
    

    save_path = gen_results_path([base_path,exp_path], changelog_flag);
    if isempty( save_path )
        return;
    end
    data_set_files = dir( [ save_path, 'data_set_*.mat' ] );
    continue_training = 0;
    cur_iteration = 1;
    cur_epoch = 1;
    set_eta = true; % learning rate is set for the network
    num_patterns = length(stimulus);

 
    if isempty(eta)
        eta = 0.001;
        set_eta = false;
    end

    if ~isempty( data_set_files )

        continue_training = sscanf( data_set_files(end).name, 'data_set_%d.mat' );

        u_input = input( sprintf( 'continue training at iteration? (default %i): ', continue_training ), 's' );

        if ~isempty( str2num( u_input ) )
            continue_training = str2num( u_input );
            cur_iteration = mod( continue_training, 100000 )+1;
            cur_epoch = floor( continue_training/100000 )+1;
            
            if (cur_iteration <= 0)
                cur_iteration = 1;
            end
            if (cur_epoch <= 0)
                cur_epoch = 1;
            end
        end
    end

%% create data sets

    if isempty( num_patterns )
        if ~isempty( pat_sequences )
            num_patterns = max( [ pat_sequences{:} ] );
        elseif ~isempty( train_set_generator )
            num_patterns = length( train_set_generator.pat_labels );
        else
            error( 'invalid parameters: unknown number of patterns!' );
        end
    end

    if ~isempty( pat_sequences )  
        if ( continue_training == 0 )

            performance = nan( num_epochs, ceil(num_train_sets/save_interval) );
            num_trials = nan( num_epochs, num_train_sets );
            all_seq_ids = zeros( num_epochs, num_train_sets );

        else

            old_path = locate_data_file( save_path, continue_training );

            if isempty( old_path )
                error( 'File not found!' );
            end

            fprintf( 'restoring experiment state %s...\n', old_path );
            old_data = load( old_path, 'patterns', 'pat_sequences', 'net', ...
                             'train_set_generator', 'performance', 'num_trials', 'all_seq_ids' );

            net = old_data.net;
            performance = old_data.performance;
            
            if isfield( old_data, 'train_set_generator' )
                train_set_generator = old_data.train_set_generator;
            end

            if isfield( old_data, 'patterns' )
                patterns = old_data.patterns;
            end
            
            if isfield( old_data, 'pat_sequences' )
                pat_sequences = old_data.pat_sequences;
            end
        end

        if isempty( pat_labels )
            if isfield( train_set_generator, 'pat_labels' )                
                pat_labels = train_set_generator.pat_labels;
            else
                num_pats = max( [pat_sequences{:}] );
                pat_labels = mat2cell( char( 'A' + (1:num_pats) - 1 ), 1, ones(1,num_pats) );
            end
        end
        num_seqs = length(pat_sequences);

        if isempty( train_set_generator )
            train_set_generator = struct();
            train_set_generator.patterns = patterns;
            train_set_generator.pat_sequences = pat_sequences;
            train_set_generator.pattern_length = pattern_length;
            train_set_generator.targets_per_pattern = targets_per_pattern;
            train_set_generator.length_std = length_std;
            train_set_generator.fcn_generate = @( data_gen, i )( generate_pattern_sequence_n( data_gen, i ) );
            train_set_generator.process = input_process;
        end

        if ischar( pat_sequences ) && strcmp( pat_sequences, 'basic_set_generator' )
            if isempty( train_set_generator )
                error( 'Basic train set generator required!' )
            end

            train_set_generator.patterns = patterns;
            train_set_generator.pattern_length = pattern_length;
            train_set_generator.targets_per_pattern = targets_per_pattern;
            train_set_generator.length_std = length_std;
            train_set_generator.process = input_process;
        end
        
    elseif isempty( train_set_generator )
        error( 'Argument ''train_set_genrator'' or ''pat_sequences'' required!' );
    elseif isfield( train_set_generator, 'pat_sequences' )
        num_seqs = length(train_set_generator.pat_sequences);
    else
        num_seqs = num_train_samples;
    end
    
    if isempty( seq_probs )
        seq_probs = ones( num_seqs, 1 )./num_seqs;
    end

    if ~isfield( train_set_generator, 'pat_labels' )
        train_set_generator.pat_labels = pat_labels;
    end
    
    if ~isempty( free_run_pat_lenghts )
        free_run_pat_lenghts(end+1) = free_run_time - sum(free_run_pat_lenghts);
        free_set_generator.pattern_length = free_run_pat_lenghts;
    end


%% create network

    snn_options( 'verbose', true );

    for epoch = cur_epoch:num_epochs

        if ( continue_training == 0 )
            num_inneurons = ceil(num_bio_neurons/4);
            net = snn_new( num_bio_neurons, num_inputs, ...
                           'train_method', train_method, ...
                           'sample_method', sample_method, ...
                           'performance_method', performance_method, ...
                           'lambda', output_rate, ...
                           'self_inhibition', self_inhibition, ...
                           'iw_track_speed', iw_track_speed, ...
                           'tau_x_r', tau_x_r, ...
                           'tau_z_r', tau_z_r, ...
                           'tau_x_f', tau_x_f, ...
                           'tau_z_f', tau_z_f, ...
                           'tau_rf', tau_rf, ...
                           'w_rf', w_rf, ...
                           'mean_rec_delay', rec_delay, ...                       
                           'use_iw', use_iw, ...
                           'eta', eta, ...
                           'groups', groups, ...
                           'use_variance_tracking', use_variance_tracking, ...
                           'num_samples', num_samples, ...
                           'num_inneurons', num_inneurons, ...
                           varargin{:} );

            if ~isempty( patterns )
                train_set_generator.patterns = patterns;
            end

            % create training/testing sets
            if regen_seqs || (epoch == 1)
                fprintf( 'creating test sets...  0%%' );

                num_test_sets = 1;%min( num_seqs, 5 );
                test_set = cell(1,num_test_sets);
                

                for i = 1:num_test_sets

                    test_set{i}.seq_id = i;        
                    train_set_generator.seq_id = i;
                    [patterns,pat_sequences,~,~,~,cue] = generate_patterns1(stimulus,T/2,N_cue);
                   
                    train_set_generator.patterns = patterns;
                    net.pat_sequences = pat_sequences;
                    net.cue = cue;
                    net.list = 1:length(stimulus);
                    test_set{i}.data = train_set_generator.fcn_generate( train_set_generator, 1 );
                    fprintf('%c%c%c%c%3d%%',8,8,8,8,round(100*i/num_seqs))
                    
                end

                fprintf('%c%c%c%cdone.\n',8,8,8,8);
                fprintf( 'creating free run sets...  0%%' );

                free_run_data = cell(1,num_test_sets);

                free_set_generator = train_set_generator;

                if ~isempty( free_run_seqs )
                    free_run_seqs;
                    for i=1:length(free_run_seqs)
                        free_run_seqs{i}(end) = length( free_set_generator.patterns );
                    end
                    free_set_generator.free_run_seqs = free_run_seqs;
                    free_set_generator.pat_sequences = free_run_seqs;
                    free_set_generator.process = input_process;
                end

                for i = 1:num_test_sets
                    free_run_data{i}.seq_id = i;
                    free_set_generator.seq_id = i;
                    [patterns,pat_sequences,~,~,~,cue] = generate_patterns1(stimulus,T/2,N_cue);
                    free_set_generator.patterns = patterns;
                    free_set_generator.pat_sequences = pat_sequences;
                    net.pat_sequences = pat_sequences;
                    net.cue = cue;
                    free_run_data{i}.data = free_set_generator.fcn_generate( free_set_generator, 1 );
                    fprintf('%c%c%c%c%3d%%',8,8,8,8,round(100*i/num_seqs))
                end

                fprintf('%c%c%c%cdone.\n',8,8,8,8);
            end
                       
            if pretrain_ff_weights
                pats = [ train_set_generator.patterns{1:num_patterns} ];
                net.W = repmat( log(pats/10), 1, ceil(num_bio_neurons/num_patterns) )';
                net.W = max( -50, net.W(1:num_bio_neurons,1:num_inputs) );
            end
            
            if ~isempty( net_V )
                net.V = net_V;
            end
        end

        continue_training = 0;
        net.num_runs = 1;

        %% Basic structure of the network
        
        net.num_inputs = num_inputs;
        net.adapt = double((rand(1,num_bio_neurons) > 0.8))'; % number of adapt neurons
        net.tao_a = 5;
        % There are three groups of ex. neurons
        net.num_bio_neurons = num_bio_neurons; % 3rd ex. neural group
        
        num_ex_left = num_bio_neurons;
        net.num_ex_left = num_ex_left; % 1st ex. neural group
        num_ex_right = num_ex_left; 
        net.num_ex_right = num_ex_right; % 2nd ex. neural group
        
        num_inneurons = ceil(3*num_bio_neurons/4); % number of in. neurons
        net.num_inneurons = num_inneurons;

        % innitial synaptic currents
        net.hX_init = zeros( num_inputs, 2 );
        net.hZleft_init = zeros( num_ex_left, 2 );
        net.hZright_init = zeros( num_ex_right, 2 );
        net.hZ_init = zeros( num_bio_neurons, 2 );
        net.hl_init = zeros( num_inneurons, 2 );


        net.reset_psps = reset_psps;
        net.ex_delay = 10; % refractory period of downstream ex. neurons
        net.inhi_delay = 3; % refractory period of downstream in. neurons
        net.RT = []; % reaction time is reset to measure performance of the network
        net.observe_size = 1; % neural responses in the current time step for identifications
        
        net.t_start = 1; % the time step to start identificaions
        net.N_cue = N_cue; % number of cue
        net.N_state = 2; % number of possible states of each cue
        % net.iden_t = zeros(length(stimulus),1);
        net.iden_t = [];
        net.action = cell(net.N_cue,net.N_state); % clustering sets for possible value of hidden cue
        for nn = 1:net.N_state
            for jj = 1:N_cue
                net.action{jj,nn} = zeros((net.num_bio_neurons + net.num_ex_left + net.num_ex_right), 1);
            end
        end

        net.stimulus = stimulus;
        net.cue = cue;
        net.delayparameter = 0.1^(1/net.observe_size);% delay contanst of reward
        net.significance = 0.1;
        net.Repeat = 50;% repeating samples in identificaitons
        net.cluster_size = 50;% size of clustering sets
        net.p_action = 1;% probability to generate identificaions
        net.p_update = net.p_action;
        net.count = zeros(N_cue,1);
        net.total_count = zeros(N_cue,1);
        net.T = T;
        net.I_firingrate =  1;
        net.eta = 0.001; % learning rate for the network
        net.n_clu_merged = zeros(N_cue,2);% N_cue is the number of hidden cues. Each cue has 2 states.
        net.learning = 1; % net is in learning simulations
        net.mu0 = 0;
        net.sigma0 = 0;
        net.noisy0 = 0;

        W = double(unifrnd(0.00001,1,num_ex_left,num_inputs/2));% basic feedforward connection
        net.Wleft = double(unifrnd(0.00001,1,num_ex_left,num_inputs/2));% basic feedforward connection
        net.Wleft0 = double(net.Wleft>0);
        net.Wright = double(unifrnd(0.00001,1,num_ex_right,num_inputs/2));% basic feedforward connection
        net.Wright0 = double(net.Wright>0);

        % lateral connection from 1st to 2nd ex. neurons
        net.VLtoR = double(unifrnd(0.00001,1,num_ex_right,num_ex_left)).*double(unifrnd(0.00001,1,num_ex_right,num_ex_left)<0.5);% E->E = 0.5
        net.VLtoR0 = double(net.VLtoR>0);
        % lateral connection from 2nd to 1st ex. neurons
        net.VRtoL = double(unifrnd(0.00001,1,num_ex_left,num_ex_right)).*double(unifrnd(0.00001,1,num_ex_left,num_ex_right)<0.5);% E->E = 0.5
        net.VRtoL0 = double(net.VRtoL>0);
        % lateral connection from 1st to 3rd ex. neurons
        net.VLtoB = double(unifrnd(0.00001,1,num_bio_neurons,num_ex_left)).*double(unifrnd(0.00001,1,num_bio_neurons,num_ex_left)<0.5);% E->E = 0.5
        net.VLtoB0 = double(net.VLtoB>0);
        % lateral connection from 3rd to 1st ex. neurons
        net.VBtoL = double(unifrnd(0.00001,1,num_ex_left,num_bio_neurons)).*double(unifrnd(0.00001,1,num_ex_left,num_bio_neurons)<0.5);% E->E = 0.5
        net.VBtoL0 = double(net.VBtoL>0);
        % lateral connection from 2nd to 3rd ex. neurons
        net.VRtoB = double(unifrnd(0.00001,1,num_bio_neurons,num_ex_right)).*double(unifrnd(0.00001,1,num_bio_neurons,num_ex_right)<0.5);% E->E = 0.5
        net.VRtoB0 = double(net.VRtoB>0);
        % lateral connection from 3rd to 2nd ex. neurons
        net.VBtoR = double(unifrnd(0.00001,1,num_ex_right,num_bio_neurons)).*double(unifrnd(0.00001,1,num_ex_right,num_bio_neurons)<0.5);% E->E = 0.5
        net.VBtoR0 = double(net.VBtoR>0);

        % lateral connection from 1st to 1st ex. neurons
        net.VLtoL = double(unifrnd(0.00001,1,num_ex_left,num_ex_left)).*double(unifrnd(0.00001,1,num_ex_left,num_ex_left)<0.5);% E->E = 0.5
        for nn = 1:num_ex_left
            net.VLtoL(nn,nn) = 0;
        end
        net.VLtoL0 = double(net.VLtoL > 0);
        % lateral connection from 2nd to 2nd ex. neurons
        net.VRtoR = double(unifrnd(0.00001,1,num_ex_right,num_ex_right)).*double(unifrnd(0.00001,1,num_ex_right,num_ex_right)<0.5);% E->E = 0.5
        for nn = 1:num_ex_right
            net.VRtoR(nn,nn) = 0;
        end
        net.VRtoR0 = double(net.VRtoR > 0);
        % lateral connection from 3st to 3st ex. neurons
        net.VBtoB = double(unifrnd(0.00001,1,num_bio_neurons,num_bio_neurons)).*double(unifrnd(0.00001,1,num_bio_neurons,num_bio_neurons)<0.5);% E->E = 0.5
        for nn = 1:num_bio_neurons
            net.VBtoB(nn,nn) = 0;
        end
        net.VBtoB0 = double(net.VBtoB > 0);
        % lateral connection from inhi. neurons to 1st ex. neurons
        net.EI_L = double(unifrnd(0.00001,1,num_ex_left,num_inneurons)).*double(unifrnd(0.00001,1,num_ex_left,num_inneurons)<0.6);% I->E = 0.6
        net.EI_L0 = double(net.EI_L > 0);
        % lateral connection from inhi. neurons to 2nd ex. neurons
        net.EI_R = double(unifrnd(0.00001,1,num_ex_right,num_inneurons)).*double(unifrnd(0.00001,1,num_ex_right,num_inneurons)<0.6);% I->E = 0.6
        net.EI_R0 = double(net.EI_R > 0);
        % lateral connection from inhi. neurons to 3rd ex. neurons
        net.EI_B = double(unifrnd(0.00001,1,num_bio_neurons,num_inneurons)).*double(unifrnd(0.00001,1,num_bio_neurons,num_inneurons)<0.6);% I->E = 0.6
        net.EI_B0 = double(net.EI_B > 0);

        
        % lateral connection from 1st ex. neurons to inhi. neurons
        net.IE_L = double(unifrnd(0.00001,1,num_inneurons,num_ex_left)).*double(unifrnd(0.00001,1,num_inneurons,num_ex_left)<0.575);% E->I = 0.575
        net.IE_L0 = double(net.IE_L > 0);
        % lateral connection from 2nd ex. neurons to inhi. neurons
        net.IE_R = double(unifrnd(0.00001,1,num_inneurons,num_ex_right)).*double(unifrnd(0.00001,1,num_inneurons,num_ex_right)<0.575);% E->I = 0.575
        net.IE_R0 = double(net.IE_R > 0);
        % lateral connection from 3rd ex. neurons to inhi. neurons
        net.IE_B = double(unifrnd(0.00001,1,num_inneurons,num_bio_neurons)).*double(unifrnd(0.00001,1,num_inneurons,num_bio_neurons)<0.575);% E->I = 0.575
        net.IE_B0 = double(net.IE_B > 0);
        % lateral connection from inhi. neurons to inhi. neurons
        net.II = double(unifrnd(0.00001,1,num_inneurons,num_inneurons)).*double(unifrnd(0.00001,1,num_inneurons,num_inneurons)<0.55);% I->I = 0.55
        net.II0 = double(net.II > 0);

        %% train network
        sim_train = {};

        for i = cur_iteration:num_train_sets

            iteration = net.iteration;
            
            if ( mod(iteration,save_interval) == 0 )&&(iteration>=2)
                net_sim = net;
                for j = 1:num_test_sets
                    net_sim.use_inhibition = true;
                    [sim_test{j},net_sim] = snn_simulate( net_sim, test_set{j}.data, 'collect', field_collectors );
                    [sim_free{j},net_sim] = snn_simulate( net_sim, free_run_data{j}.data, 'collect', field_collectors );
                end
                data_set.net = net;
                data_set.sim_train = sim_train;
                data_set.sim_test = sim_test;
                data_set.sim_free = sim_free;
                data_set.performance = performance;
                data_set.state = state;
                if show_fig
                    plot_data_set( data_set );
                end
                file_name = [ save_path, sprintf( 'data_set_%03d%05d.mat', epoch-1, iteration ) ];
                fprintf( 'saving results to: %s...\n', file_name );
                save( file_name, 'net', 'sim_train', 'sim_test', 'sim_free', 'all_seq_ids', ...
                      'performance', 'train_set_generator', 'free_set_generator', ...
                      'num_trials', 'seq_probs','state' );
            end
            
            iteration = iteration+1;

            if isempty( seq_ids )
                seq_id = find( cumsum(seq_probs) > rand(), 1 );
            else
                seq_id = seq_ids( mod(i-1,length(seq_ids))+1 );
            end
            [patterns,pat_sequences,~,~,~,cue] = generate_patterns1(stimulus,T/2,N_cue);

            net.patterns = patterns;
            net.list = 1:length(stimulus);
            net.pat_sequences = pat_sequences;
            net.cue = cue;
            all_seq_ids( epoch, i ) = seq_id;
            train_set_generator.seq_id = seq_id;
            fprintf( '\niteration: %i\n', iteration );
 
            net.num_runs = num_runs;
            [net,sim_train] = snn_update_ct( net, [], ...
                                             'set_generator', train_set_generator, ...
                                             'collect', field_collectors );
           toc;
           num_trials( epoch, i ) = net.num_trials;

            net.num_runs = 1;

            sim_test = cell(num_seqs,1);
            sim_free = cell(num_seqs,1);

            
        end

        cur_iteration = 1;
        
    end
end