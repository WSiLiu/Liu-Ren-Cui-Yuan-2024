function data = plot_mem_task( data, neurons,varargin )
% Plot the data structure.
% If a string is given the data structure
% is loaded from the file it points to.
%

    if ischar( data )
        data = load( data );
    end
    
    [ num_z_neurons, ...
      max_num_trials, ...
      idx, ...
      set_name, ...
      plot_spikes, ...
      highlight_groups, ...
      seq_id, ...
      run_id, ...
      single_neuron_seq_ids, ...
      dy, ...
      peth_set, ...
      base_path, ...
      fig_file ] = snn_process_options( varargin, ...
                                        'num_neurons', [], ...
                                        'max_num_trials', 20, ...
                                        'neuron_order', [], ...
                                        'data_set', 'free_data', ...
                                        'plot_spikes', true, ...
                                        'highlight_groups', [], ...
                                        'seq_id', 1, ...
                                        'run_id', 1, ...
                                        'single_neuron_seq_ids', [], ...
                                        'dy', 2, ...
                                        'peth_set', 'peth_free', ...
                                        'base_path', '', ...
                                        'fig_file', [] );
    
    colors = snn_options( 'colors' );
    %num_z_neurons
    %  seq_id = 1;set_name = 'free_data';neurons = [];dy = 2;
    
%     %   single_neuron_seq_ids = [];
%     if isempty(idx)
%         rank = data.rank_test{seq_id};
%         idx = zeros(size(rank));
%         idx(rank) = 1:length(rank);
%     end
    [num_seqs,num_trials] = size(data.(set_name));
    num_neurons = max( idx );
    
    if isempty( num_z_neurons )
        num_z_neurons = 1:num_neurons;
    end
    num_z_neurons;
    num_trials = min( max_num_trials, num_trials );

    [h,fig] = get_grid_layout( 1000*data.(set_name){1}.time(end), ...
                               [repmat( num_trials, 1, length(neurons) ), length( num_z_neurons ) ], ...
                               'plot_y_border', [repmat(6,1,length(neurons)-1),40], ...
                               'dy', dy, 'right_border', 40 );
                    
    x_limit = [ 1000*data.(set_name){seq_id}.time(1), 1000*data.(set_name){seq_id}.time(end) ];
    
    show_labels = true;
    
    if isempty(single_neuron_seq_ids)
        single_neuron_seq_ids = repmat(seq_id,1,length(neurons));
    end
    num_z_neurons;
    idx = [ idx(num_z_neurons), idx(  not(sparse( 1, num_z_neurons, true, 1, length(idx) )) ) ];
%     
%     for i=1:length(neurons)
%         
%         plot_single_neuron_trials( data, neurons(i), ...
%                                    'trials', 1:num_trials, ...
%                                    'seq_id', single_neuron_seq_ids(i), ...
%                                    'num_neurons', num_neurons, ...
%                                    'neuron_order', idx, ...
%                                    'set_name', set_name, ...
%                                    'neuron_labels', 1:num_neurons, ...
%                                    'plot_axis', h(i) )
% %                                
% %         if show_labels
% %             snn_plot( data.(set_name){seq_id}, '[ Xt[?tl] ]', 'axis', h(i), ...
% %                       'numbering', 'none', 'colors', colors, ...
% %                       'show_titles', false );
% %             show_labels = false;
% %         else
% %             snn_plot( data.(set_name){seq_id}, '[ Xt[?t] ]', 'axis', h(i), ...
% %                       'numbering', 'none', 'colors', colors, ...
% %                       'show_titles', false );
% %         end
%                     
%         if (i==length(neurons))
%             set( h(i), 'Box', 'off', 'YTick', [1,num_trials] );
%             xlabel( 'time [ms]' );
%         else
%             set( h(i), 'Box', 'off', 'XTickLabel', [], 'YTick', [1,num_trials] );
%         end
%         xlim( x_limit );
%         axes( h(i) );  ylabel( 'trial' );
%     end
%     
%     axes( h(end) ); xlabel( 'time [ms]' );
    %%% 
    peth_set;
    im_data =  data.(peth_set){seq_id}; %./...
    
    lim = ceil(max(max(im_data)));
    imagesc( 1000*data.(set_name){seq_id}.time, ...
             1:length( num_z_neurons ), im_data(idx(1:length(num_z_neurons)),:), [0,lim] );
         %%%%
   colormap( [1:(-1/255):(0); 1:(-1/255):(0); 1:(-1/255):(0)]' );
   plot_spikes = false;
%     if plot_spikes
%         group_ids = cumsum( [0,data.net.groups] );
%         group_labels = zeros(1,data.net.num_neurons);
%         col = 1;
%         for i = 1:length(data.net.groups)
%             if any(highlight_groups == i)
%                 group_labels((group_ids(i)+1):group_ids(i+1)) = col;
%                 col = col+1;                
%             else
%                 group_labels((group_ids(i)+1):group_ids(i+1)) = size(colors,1);
%             end
%         end
%         plot_data_hist( data, 'set_name', set_name, ...
%                         'neuron_order', idx, ...
%                         'plot_axis', h(end), ...
%                         'hold', 'on', ...
%                         'seq_id', seq_id, ...
%                         'run_id', run_id, ...
%                         'neuron_labels', group_labels, ...
%                         'z_labels', data.(set_name){seq_id}.labels, ...
%                         'num_neurons', length( num_z_neurons ) );
%     else
%         snn_plot( data.(set_name){seq_id}, '[ Xt[?tl] ]', 'axis', h(end), ...
%                       'numbering', 'none', 'colors', colors, ...
%                       'show_titles', false, 'hold', 'off' );
%     end
    dd =1 ;
    yticks = num_z_neurons(1);l = 1;
    while (l*dd<num_z_neurons(end))
        yticks = [yticks,l*dd];
         l = l+1;
    end
     yticks = double([yticks,num_z_neurons]);
    [num_z_neurons(1),num_z_neurons(end)];
%     set( h(end), 'LineWidth', 0.8, 'FontName', snn_options( 'FontName' ), ...
%                  'FontSize', snn_options( 'FontSize' ), ...
%                  'YTick', [1,100,200,300,400] );
             
    ylabel( 'neuron' );
    xlabel( 'time [ms]' );
    set(gcf,'Position',[100 100 260 220]);
% %     set(gca,'Position',[.13 .17 .80 .74]);
    figure_FontSize=8;
    set(get(gca,'XLabel'),'FontSize',figure_FontSize,'Vertical','top');
    set(get(gca,'YLabel'),'FontSize',figure_FontSize,'Vertical','middle');
    set(findobj('FontSize',10),'FontSize',figure_FontSize);
    set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',2);
    
    bar_pos = get( h(end), 'Position' );
    plot_width = bar_pos(3);
    bar_pos(3) = bar_pos(1)*0.4;
    bar_pos(1) = bar_pos(1)*1.2 + plot_width;
    bar_pos(2) = bar_pos(2);+ bar_pos(4)*0.1;
    bar_pos(4) = bar_pos(4);
% %'YTick', [0,1], 
    colorbar( 'West', 'Position', bar_pos, ...
              'LineWidth', 0.8, 'FontName', snn_options( 'FontName' ), ...
              'FontSize', snn_options( 'FontSize' ) );
    %save(h(end));
%     if ~isempty( fig_file )
%         save_fig( fig, [fig_file,'_peth'], base_path );
%     end
    saveas(gcf,'save.jpg');
    [h,fig] = get_grid_layout( 65, repmat( 65, 1, num_seqs ), ...
                               'plot_y_border', 25, ...
                               'plot_x_border', 25, ...
                               'dx', 1, 'dy', 1 );
%     
%     for i = 1:num_seqs
%         axes( h(i) ); hist( data.spear_free(i,:), -1:0.2:1 ); xlim([-1.1,1.1]);
%         ylim([0,100]);
%         hold on; plot( repmat(data.spear_av(i),1,2), [0,100], '-r' );
%         set( gca, 'YTick', [0,100], 'LineWidth', 0.8, 'FontName', snn_options( 'FontName' ), ...
%              'FontSize', snn_options( 'FontSize' ) );
%          
%         ylabel( '# trials' );
%         title( 'ABEFG' );
%     end    
%     xlabel( 'rank corr.' );
    
%     if ~isempty( fig_file )
%         save_fig( fig, [fig_file,'_corr'], base_path );
%     end
end
