function Assembles = Neuralassemble(Assembles,Spiketrain_Wilcoxon_test)
N_neuron = size(Spiketrain_Wilcoxon_test,1);
N_sti = size(Spiketrain_Wilcoxon_test,2);
for n = 1:N_neuron
    if (Spiketrain_Wilcoxon_test(n,1) == 1)
        Assembles{1,1} = [Assembles{1,1};n];
    elseif (Spiketrain_Wilcoxon_test(n,2) == 1)
        Assembles{2,1} = [Assembles{2,1};n];
    else
        Assembles{3,1} = [Assembles{3,1};n];

    end
end
end